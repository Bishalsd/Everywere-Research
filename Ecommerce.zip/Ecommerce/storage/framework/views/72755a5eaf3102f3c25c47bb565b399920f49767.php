
<?php 
use App\Models\Banner;
  $getBanners = Banner::getBanners();
//   echo "<pre>"; print_r($getBanners); die;

 ?>
<?php if(isset($page_name) && $page_name == "index"): ?>
<div id="carouselBlk">
	<div id="myCarousel" class="carousel slide">
		<div class="carousel-inner">
      <?php $__currentLoopData = $getBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="item <?php if($key==0): ?> active <?php endif; ?>">
				<div class="container">
					<a <?php if(!empty($banner['link'])): ?> href="<?php echo e(url($banner['link'])); ?>" <?php else: ?> href="javascript:void(0)" <?php endif; ?>><img style="width:100%;" src="<?php echo e(asset('backEnd/images/banners/'.$banner['image'])); ?>" alt="<?php echo e($banner['alt']); ?>" title="<?php echo e($banner['title']); ?>"/></a>
				</div>
			</div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
		<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
	</div>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/front/banners/home_page_banners.blade.php ENDPATH**/ ?>