    <script src="<?php echo e(asset('backEnd/js/bootstrap.bundle.min.js')); ?>"></script> 
	<!--plugins-->
	<script src="<?php echo e(asset('backEnd/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
	<!--app JS-->
	<script src="<?php echo e(asset('backEnd/js/app.js')); ?>"></script>
	<script src="<?php echo e(asset('backEnd/js/custom_js.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/layouts/admin_layouts/footer_script.blade.php ENDPATH**/ ?>