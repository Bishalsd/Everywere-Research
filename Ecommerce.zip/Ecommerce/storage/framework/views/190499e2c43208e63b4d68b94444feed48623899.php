<?php 
use App\Models\Product; 
?>

<?php $__env->startSection("content"); ?>

<div class="span9">
  <ul class="breadcrumb">
    <li><a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo e(url('/'.$productDetails['category']['url'])); ?>"><?php echo e($productDetails['category']['name']); ?></a> <span class="divider">/</span></li>
    <li class="active"><?php echo e($productDetails['product_name']); ?></li>
  </ul>
  <div class="row">
    <div id="gallery" class="span3">
      <?php $product_image_path = "backEnd/images/products/large/".$productDetails['main_image']; ?>
			<?php if(!empty($productDetails['main_image']) && file_exists($product_image_path)): ?>
        <a href="<?php echo e(asset($product_image_path)); ?>" title="Blue Casual T-Shirt">
          <img src="<?php echo e(asset($product_image_path)); ?>" style="width:100%" alt="Blue Casual T-Shirt"/>
      </a>
			<?php else: ?>
				<img src="<?php echo e(asset('backEnd/images/products/small/no-image.png')); ?>" alt="">
			<?php endif; ?>
      <div id="differentview" class="moreOptopm carousel slide">
        <div class="carousel-inner">
          <div class="item active">
            <?php $__currentLoopData = $productDetails['product_image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(asset('backEnd/images/products/large/'.$image['image'])); ?>"> <img style="width:29%" src="<?php echo e(asset('backEnd/images/products/large/'.$image['image'])); ?>" alt=""/></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <!--
              <a class="left carousel-control" href="#myCarousel" data-slide="prev">‹</a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">›</a>
        -->
      </div>

      <div class="btn-toolbar">
        <div class="btn-group">
          <span class="btn"><i class="fas fa-envelope"></i></span>
          <span class="btn" ><i class="fas fa-print"></i></span>
          <span class="btn" ><i class="fas fa-search"></i></span>
          <span class="btn" ><i class="fas fa-star"></i></span>
          <span class="btn" ><i class="fas fa-thumbs-up"></i></span>
          <span class="btn" ><i class="fas fa-thumbs-down"></i></span>
        </div>
      </div>
    </div>
    <div class="span6">
      <?php if(Session::has('success_message')): ?>
     <div class="alert alert-success" role="alert">
       <?php echo e(Session::get('success_message')); ?>

       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>
     <?php endif; ?>
     <?php if(Session::has('error_message')): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e(Session::get('error_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php endif; ?>
      <h3><?php echo e($productDetails['product_name']); ?></h3>
      <small>- <?php echo e($productDetails['brand']['name']); ?></small>
      <hr class="soft"/>
      <small><?php echo e($total_stock); ?> items in stock</small>
      <form action="<?php echo e(url('add-to-cart')); ?>" method="post" class="form-horizontal qtyFrm">
        <?php echo csrf_field(); ?>
        
        <input type="hidden" name="product_id" value="<?php echo e($productDetails['id']); ?>">
        <div class="control-group">
        <?php $discounted_price = Product::getDiscountedPrice($productDetails['id']); ?>
          <h4 class="getAttrPrice">
          <?php if($discounted_price>0): ?>
            <del>৳.<?php echo e($productDetails['product_price']); ?></del> ৳.<?php echo e($discounted_price); ?>

          <?php else: ?> 
           ৳.<?php echo e($productDetails['product_price']); ?>

          <?php endif; ?>
          </h4>
            <select  name="size" id="getPrice" product-id="<?php echo e($productDetails['id']); ?>" class="span2 pull-left" required="">
              <option value="">Select Size</option>
              <?php $__currentLoopData = $productDetails['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($attribute['size']); ?>"><?php echo e($attribute['size']); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input name="quantity" type="number" min="1" class="span1" placeholder="Qty."/ required>
            <button type="submit" class="btn btn-large btn-primary pull-right"> Add to cart <i class=" icon-shopping-cart"></i></button>
          </div>
        </div>
      </form>

      <hr class="soft clr"/>
      <p class="span6">
        <?php echo e($productDetails['description']); ?>

      </p>
      <a class="btn btn-small pull-right" href="#detail">More Details</a>
      <br class="clr"/>
      <a href="#" name="detail"></a>
      <hr class="soft"/>
    </div>

    <div class="span9">
      <ul id="productDetail" class="nav nav-tabs">
        <li class="active"><a href="#home" data-toggle="tab">Product Details</a></li>
        <li><a href="#profile" data-toggle="tab">Related Products</a></li>
      </ul>
      <div id="myTabContent" class="tab-content">
        <div class="tab-pane fade active in" id="home">
          <h4>Product Information</h4>
          <table class="table table-bordered">
            <tbody>
              <tr class="techSpecRow"><th colspan="2">Product Details</th></tr>
              <tr class="techSpecRow"><td class="techSpecTD1">Brand: </td><td class="techSpecTD2"><?php echo e($productDetails['brand']['name']); ?></td></tr>
              <tr class="techSpecRow"><td class="techSpecTD1">Code:</td><td class="techSpecTD2"><?php echo e($productDetails['product_code']); ?></td></tr>
              <tr class="techSpecRow"><td class="techSpecTD1">Color:</td><td class="techSpecTD2"><?php echo e($productDetails['product_color']); ?></td></tr>
              <?php if(!empty($productDetails['fabric'])): ?>
              <tr class="techSpecRow"><td class="techSpecTD1">Fabric:</td><td class="techSpecTD2"><?php echo e($productDetails['fabric']); ?></td></tr>
              <?php endif; ?>
              <?php if(!empty($productDetails['pattern'])): ?>
              <tr class="techSpecRow"><td class="techSpecTD1">Pattern:</td><td class="techSpecTD2"><?php echo e($productDetails['pattern']); ?></td></tr>
              <?php endif; ?>
              <?php if(!empty($productDetails['sleeve'])): ?>
              <tr class="techSpecRow"><td class="techSpecTD1">Sleeve:</td><td class="techSpecTD2"><?php echo e($productDetails['sleeve']); ?></td></tr>
              <?php endif; ?>
              <?php if(!empty($productDetails['fit'])): ?>
              <tr class="techSpecRow"><td class="techSpecTD1">Fit:</td><td class="techSpecTD2"><?php echo e($productDetails['fit']); ?></td></tr>
              <?php endif; ?>
              <?php if(!empty($productDetails['occasion'])): ?>
              <tr class="techSpecRow"><td class="techSpecTD1">Occasion:</td><td class="techSpecTD2"><?php echo e($productDetails['occasion']); ?></td></tr>
              <?php endif; ?>
            </tbody>
          </table>

          <h5>Washcare</h5>
          <p><?php echo e($productDetails['wash_care']); ?></p>

        </div>
        <div class="tab-pane fade" id="profile">
          <div id="myTab" class="pull-right">
            <a href="#listView" data-toggle="tab"><span class="btn btn-large"><i class="fas fa-th-list"></i></span></a>
            <a href="#blockView" data-toggle="tab"><span class="btn btn-large btn-primary"><i class="fas fa-th-large"></i></span></a>
          </div>
          <br class="clr"/>
          <hr class="soft"/>
          <div class="tab-content">
            <div class="tab-pane" id="listView">
              <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                  <div class="span2">
                    <?php $product_image_path = "backEnd/images/products/small/".$product['main_image']; ?>
                    <?php if(!empty($product['main_image']) && file_exists($product_image_path)): ?>
                    <img src="<?php echo e(asset($product_image_path)); ?>" alt="">
                    <?php else: ?>
                    <img src="<?php echo e(asset('backEnd/images/products/small/no-image.png')); ?>" alt="">
                    <?php endif; ?>
                  </div>
                  <div class="span4">
                    <h3><?php echo e($product['product_name']); ?></h3>
                    <hr class="soft"/>
                    <h5><?php echo e($product['product_code']); ?> | <?php echo e($product['product_color']); ?> </h5>
                    <p>
                      <?php echo e($product['description']); ?>

                    </p>
                    <a class="btn btn-small pull-right" href="<?php echo e(url($product['id'])); ?>">View Details</a>
                    <br class="clr"/>
                  </div>
                  <div class="span3 alignR">
                    <form class="form-horizontal qtyFrm">
                      <h3> ৳.<?php echo e($product['product_price']); ?></h3>
                      <label class="checkbox">
                        <input type="checkbox">  Adds product to compair
                      </label><br/>
                      <div class="btn-group">
                      <a href="#" class="btn btn-large btn-primary"> Add to <i class="fas fa-cart-plus"></i></a>
                        <a href="<?php echo e(url($product['id'])); ?>" class="btn btn-large"><i class="fas fa-search-plus"></i></a>
                      </div>
                    </form>
                  </div>
                </div>
                <hr class="soft"/>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


            <div class="tab-pane active" id="blockView">
              <ul class="thumbnails">
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="span3">
                  <div class="thumbnail">
                    <a href="<?php echo e(url($reproduct['id'])); ?>">
                        <?php $product_image_path = "backEnd/images/products/small/".$reproduct['main_image']; ?>
                        <?php if(!empty($reproduct['main_image']) && file_exists($product_image_path)): ?>
                        <img src="<?php echo e(asset($product_image_path)); ?>" alt="">
                        <?php else: ?>
                        <img src="<?php echo e(asset('backEnd/images/products/small/no-image.png')); ?>" alt="">
                        <?php endif; ?>
                    </a>
                    <div class="caption">
                      <h5><?php echo e($reproduct['product_name']); ?></h5>
                      <p>
                        <?php echo e($reproduct['product_code']); ?> | <?php echo e($product['product_color']); ?>

                      </p>
                      <h4 style="text-align:center"><a class="btn" href="<?php echo e(url($reproduct['id'])); ?>"> <i class="fas fa-search-plus"></i></a> <a class="btn" href="#">Add to <i class="fas fa-cart-plus"></i></a> <a class="btn btn-primary" href="#">৳.<?php echo e($product['product_price']); ?></a></h4>
                    </div>
                  </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <hr class="soft"/>
            </div>
          </div>
          <br class="clr">
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/front/products/detail.blade.php ENDPATH**/ ?>