<?php
	use App\Models\Section;
	$sections = Section::sections();
	// echo "<pre>"; print_r($sections); die;
 ?>

<div id="header">
	<div class="container">
		<div id="welcomeLine" class="row">
			<div class="span6">Welcome!<strong> User</strong></div>
			<div class="span6">
				<div class="pull-right">
					<a href="<?php echo e(url('cart')); ?>"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> [ <span class="totalCartItems"><?php echo e(totalCartItems()); ?></span>  ] Items in your cart </span> </a>
				</div>
			</div>
		</div>
		<!-- Navbar ================================================== -->
		<section id="navbar">
		  <div class="navbar">
		    <div class="navbar-inner">
		      <div class="container">
		        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		          <span class="icon-bar"></span>
		        </a>
		        <a class="brand" href="<?php echo e(url('/')); ?>">Online Store BD</a>
		        <div class="nav-collapse">
		          <ul class="nav">
		            <li class="active"><a href="#">Home</a></li>
		           
		            <li><a href="<?php echo e(url('custom-tailor')); ?>">Custom Tailor</a></li>
					<li><a href="#">About</a></li>
					<li><a href="#">Contact</a></li>
		          </ul>
		          <form class="navbar-search pull-left" action="#">
		            <input type="text" class="search-query span2" placeholder="Search"/>
		          </form>
		          <ul class="nav pull-right">
				  
				  <li class="divider-vertical"></li>
					<?php if(Auth::check()): ?>
						<li><a href="<?php echo e(url('/account')); ?>">My Account</a></li>
						<li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
					<?php else: ?>
		            <li><a href="<?php echo e(url('login-register')); ?>">Login / Registation</a></li>
					<?php endif; ?>
		          </ul>
		        </div><!-- /.nav-collapse -->
		      </div>
		    </div><!-- /navbar-inner -->
		  </div><!-- /navbar -->
		</section>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/layouts/front_layouts/front_header.blade.php ENDPATH**/ ?>