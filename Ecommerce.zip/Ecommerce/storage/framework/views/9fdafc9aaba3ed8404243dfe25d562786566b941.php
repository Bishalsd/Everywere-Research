
<?php $__env->startSection('front_css'); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/front/custom-tailor/custom-tailor.blade.php ENDPATH**/ ?>