<?php
	use App\Models\Section;
	$sections = Section::sections();
	// echo "<pre>"; print_r($sections); die;
 ?>

			<div id="sidebar" class="span3">
				<div class="well well-small"><a id="myCart" href="<?php echo e(url('cart')); ?>"><img src="<?php echo e(asset('front/images/ico-cart.png')); ?>" alt="cart"><span class="totalCartItems"> <?php echo e(totalCartItems()); ?> </span> Items in your cart</a></div>
				<ul id="sideManu" class="nav nav-tabs nav-stacked">
					 <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <?php if(count($section['categories']) > 0): ?>
					<li class="subMenu"><a><?php echo e($section->name); ?></a>
						<ul>
							<?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e($category['url']); ?>"><i class="icon-chevron-right"></i><strong><?php echo e($category->name); ?></strong></a></li>
								<?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><a href="<?php echo e($subcategorie['url']); ?>"><i class="icon-chevron-right"></i><?php echo e($subcategorie->name); ?></a></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</li>
					 <?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
				<br>
				<?php if(isset($page_name) && $page_name =='listing'): ?>
					<div class="well well-small">
						<h5>Favric</h5>
						<?php $__currentLoopData = $fabricArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input class="fabric" style="margin-top:-3px;" type="checkbox" name="fabric[]" id="<?php echo e($fabric); ?>" value="<?php echo e($fabric); ?>">&nbsp;&nbsp;<?php echo e($fabric); ?><br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="well well-small">
						<h5>Sleeve</h5>
						<?php $__currentLoopData = $sleeveArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input class="sleeve" style="margin-top:-3px;" type="checkbox" name="sleeve[]" id="<?php echo e($sleeve); ?>" value="<?php echo e($sleeve); ?>">&nbsp;&nbsp;<?php echo e($sleeve); ?><br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="well well-small">
						<h5>Pattern</h5>
						<?php $__currentLoopData = $patternArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input class="pattern" style="margin-top:-3px;" type="checkbox" name="pattern[]" id="<?php echo e($pattern); ?>" value="<?php echo e($pattern); ?>">&nbsp;&nbsp;<?php echo e($pattern); ?><br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="well well-small">
						<h5>Fit</h5>
						<?php $__currentLoopData = $fitArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input class="fit" style="margin-top:-3px;" type="checkbox" name="fit[]" id="<?php echo e($fit); ?>" value="<?php echo e($fit); ?>">&nbsp;&nbsp;<?php echo e($fit); ?><br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="well well-small">
						<h5>Occasion</h5>
						<?php $__currentLoopData = $occsionArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input class="occasion" style="margin-top:-3px;" type="checkbox" name="occasion[]" id="<?php echo e($occasion); ?>" value="<?php echo e($occasion); ?>">&nbsp;&nbsp;<?php echo e($occasion); ?><br>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				<?php endif; ?>
				<br/>
				<div class="thumbnail">
					<img src="<?php echo e(asset('front/images/payment_methods.png')); ?>" title="Payment Methods" alt="Payments Methods">
					<div class="caption">
						<h5>Payment Methods</h5>
					</div>
				</div>
			</div>
<?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/layouts/front_layouts/front_sitebar.blade.php ENDPATH**/ ?>