<?php use App\Models\Product; ?>
<div class="tab-pane  active" id="blockView">
  <ul class="thumbnails">
    <?php $__currentLoopData = $categoryProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="span3">
      <div class="thumbnail">
        <a href="<?php echo e(url($Product->id)); ?>">
          <?php if(isset($Product['main_image'])): ?>
          <?php $product_image_path = "backEnd/images/products/small/".$Product['main_image']; ?>
          <?php else: ?>
          <?php $product_image_path = ""; ?>
          <?php endif; ?>
          <?php $product_image_path = "backEnd/images/products/small/".$Product['main_image']; ?>
          <?php if(!empty($Product['main_image']) && file_exists($product_image_path)): ?>
          <img src="<?php echo e(asset($product_image_path)); ?>" alt="">
          <?php else: ?>
          <img src="<?php echo e(asset('backEnd/images/products/small/no-image.png')); ?>" alt="">
          <?php endif; ?>
        </a>
        <div class="caption">
          <h5><?php echo e($Product['product_name']); ?></h5>
          <?php $discounted_price = Product::getDiscountedPrice($Product->id); ?>
          <p>
            <?php echo e($Product['brand']['name']); ?>  <?php if($discounted_price>0): ?>
            | ৳.<del><?php echo e($Product['product_price']); ?></del>
            <?php endif; ?>
          </p>
          <h4 style="text-align:center"><a class="btn" href="<?php echo e(url($Product->id)); ?>"> <i class="fas fa-search-plus"></i></a> <a class="btn" href="#">Add to <i class="fas fa-cart-plus"></i></a> <a class="btn btn-primary" href="#"><?php if($discounted_price>0): ?> ৳.<?php echo e(round($discounted_price,0 )); ?> <?php else: ?> ৳.<?php echo e($Product['product_price']); ?> <?php endif; ?></a></h4>

        </div>
      </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <hr class="soft"/>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/front/products/ajax_products_listing.blade.php ENDPATH**/ ?>