<?php 
use App\Models\Product; ?>

<?php $__env->startSection("content"); ?>


<div class="span9">
				<div class="well well-small">
					<h4>Featured Products <small class="pull-right"><?php echo e($featuredItemCount); ?> featured products</small></h4>
					<div class="row-fluid">
						<div id="featured" <?php if(($featuredItemCount)>4): ?> class="carousel slide" <?php endif; ?>>
							<div class="carousel-inner">
								<?php $__currentLoopData = $featuredItemChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $featuredItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item <?php if($key ==1): ?>active <?php endif; ?>">
									<ul class="thumbnails">
										<?php $__currentLoopData = $featuredItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="span3">
											<div class="thumbnail">
												<i class="tag"></i>
												<a href="<?php echo e(url($item['id'])); ?>">
													<?php $product_image_path = "backEnd/images/products/small/".$item['main_image']; ?>
													<?php if(!empty($item['main_image']) && file_exists($product_image_path)): ?>
													<img src="<?php echo e(asset($product_image_path)); ?>" alt="">
													<?php else: ?>
													<img src="<?php echo e(asset('backEnd/images/products/small/no-image.png')); ?>" alt="">
													<?php endif; ?>
												</a>
												
												<div class="caption">
												<?php $discounted_price = Product::getDiscountedPrice($item['id']); ?>
													<h5><?php echo e($item['product_name']); ?></h5>
													<h4><a class="btn" href="<?php echo e(url($item['id'])); ?>">VIEW</a> <span class="pull-right"><?php if($discounted_price>0): ?> <small>৳.<del><?php echo e($item['product_price']); ?></del></small> <?php else: ?> ৳.<?php echo e($item['product_price']); ?> <?php endif; ?>  <?php if($discounted_price>0): ?> ৳.<?php echo e($discounted_price); ?>  <?php endif; ?></span></h4>
												</div>
											</div>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							
						</div>
					</div>
				</div>
				<h4>Latest Products </h4>
				<ul class="thumbnails">
					<?php $__currentLoopData = $newProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="span3">
						<div class="thumbnail">
							<a  href="<?php echo e(url($product['id'])); ?>"><?php $product_image_path = "backEnd/images/products/small/".$product['main_image']; ?>
								<?php if(!empty($product['main_image']) && file_exists($product_image_path)): ?>
								<img width="150" src="<?php echo e(asset($product_image_path)); ?>" alt="">
								<?php else: ?>
								<img width="150" src="<?php echo e(asset('backEnd/images/products/small/no-image.png')); ?>" alt="">
								<?php endif; ?>
							</a>
							<div class="caption">
							<?php $discounted_price = Product::getDiscountedPrice($product['id']); ?>
								<h5><?php echo e($product['product_name']); ?></h5>
								<p>
									<?php echo e($product['product_code']); ?> | <?php echo e($product['product_color']); ?> <?php if($discounted_price>0): ?> | <small>৳.<del><?php echo e($product['product_price']); ?></del></small><?php endif; ?>
								</p>

								<h4 style="text-align:center"><a class="btn" href="<?php echo e(url($product['id'])); ?>"><i class="fas fa-search-plus"></i></a> <a class="btn" href="#">Add to <i class="fas fa-cart-plus"></i></a> <a class="btn btn-primary" href="#"><?php if($discounted_price>0): ?> ৳.<?php echo e($discounted_price); ?> <?php else: ?> ৳.<?php echo e($product['product_price']); ?> <?php endif; ?></a></h4>
							</div>
						</div>
					</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
     </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.front_layouts.front_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Advance-Ecommerce\Ecommerce\resources\views/front/index.blade.php ENDPATH**/ ?>