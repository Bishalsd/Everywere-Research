<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomTailorController extends Controller
{
    public function customTailor(){
        return view("front.custom-tailor.custom-tailor");
    } 
}
