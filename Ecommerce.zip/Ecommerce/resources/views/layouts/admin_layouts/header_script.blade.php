	<!--plugins-->
	<link href="{{asset('backEnd/plugins/simplebar/css/simplebar.css')}}" rel="stylesheet" />
	<link href="{{asset('backEnd/plugins/perfect-scrollbar/css/perfect-scrollbar.css')}}" rel="stylesheet" />
	<link href="{{asset('backEnd/plugins/metismenu/css/metisMenu.min.css')}}" rel="stylesheet" />
	<!-- loader-->
	<link href="{{asset('backEnd/css/pace.min.css')}}" rel="stylesheet" />
	<script src="{{asset('backEnd/js/pace.min.js')}}"></script>
	<!-- Bootstrap CSS -->
	<link href="{{asset('backEnd/css/bootstrap.min.css')}}" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&amp;display=swap" rel="stylesheet">
	<link href="{{asset('backEnd/css/app.css')}}" rel="stylesheet">
	<link href="{{asset('backEnd/css/icons.css')}}" rel="stylesheet">
	<!-- Theme Style CSS -->
	<link rel="stylesheet" href="{{asset('backEnd/css/dark-theme.css')}}" />
	<link rel="stylesheet" href="{{asset('backEnd/css/semi-dark.css')}}" />
	<link rel="stylesheet" href="{{asset('backEnd/css/header-colors.css')}}" />
	<!-- sweetalert -->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>