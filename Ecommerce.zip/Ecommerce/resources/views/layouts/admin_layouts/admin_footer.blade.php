<footer class="page-footer">
	<p class="mb-0">Copyright © <?php echo date('Y'); ?>. All right reserved.</p>
</footer>