    <script src="{{asset('backEnd/js/bootstrap.bundle.min.js')}}"></script> 
	<!--plugins-->
	<script src="{{asset('backEnd/js/jquery.min.js')}}"></script>
	<script src="{{asset('backEnd/plugins/simplebar/js/simplebar.min.js')}}"></script>
	<script src="{{asset('backEnd/plugins/metismenu/js/metisMenu.min.js')}}"></script>
	<script src="{{asset('backEnd/plugins/perfect-scrollbar/js/perfect-scrollbar.js')}}"></script>
	<!--app JS-->
	<script src="{{asset('backEnd/js/app.js')}}"></script>
	<script src="{{asset('backEnd/js/custom_js.js')}}"></script>