@extends("layouts.admin_layouts.admin_layout")
@section('title','Dashboard')
@section("content")
<div class="page-wrapper">
	<div class="page-content">
        
    </div>
</div>
@endsection