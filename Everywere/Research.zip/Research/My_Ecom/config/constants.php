<?php

return [
    'SITE_NAME'=>'My ECOM'
];